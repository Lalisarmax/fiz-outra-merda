<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "<h1>🔍 Debug 3 - Teste do verificar_email.php isolado</h1>";

echo "<h2>1. Iniciando sessão:</h2>";
session_start();

// Simular sessão
$_SESSION['email_verificacao'] = 'teste@teste.com';
$_SESSION['nome_verificacao'] = 'Teste';

echo "<p style='color:green;'>✅ Sessão configurada</p>";
echo "<pre>Sessão: " . print_r($_SESSION, true) . "</pre>";

echo "<h2>2. Testando enviar_email.php ISOLADO:</h2>";

// Testar apenas o carregamento do enviar_email.php
try {
    echo "<p>Tentando incluir enviar_email.php...</p>";
    require_once 'enviar_email.php';
    echo "<p style='color:green;'>✅ enviar_email.php carregado</p>";
    echo "<p>Função existe? " . (function_exists('enviarCodigoVerificacao') ? 'SIM ✅' : 'NÃO ❌') . "</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
} catch (Error $e) {
    echo "<p style='color:red;'>❌ Erro Fatal: " . $e->getMessage() . " na linha " . $e->getLine() . "</p>";
}

echo "<h2>3. Testando APENAS o HTML do verificar_email.php:</h2>";
echo "<p>Vamos ver se o HTML aparece...</p>";

echo "<hr>";
echo "<h3>Incluindo verificar_email.php com require_once...</h3>";
echo "<hr>";

try {
    ob_start();
    require_once 'verificar_email.php';
    $output = ob_get_clean();
    echo "<p>Bytes gerados: <strong>" . strlen($output) . "</strong></p>";
    echo "<hr>";
    echo $output;
    echo "<hr>";
    echo "<p style='color:green;'>✅ verificar_email.php executado</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
} catch (Error $e) {
    echo "<p style='color:red;'>❌ Erro Fatal: " . $e->getMessage() . " na linha " . $e->getLine() . "</p>";
}

echo "<h2>✅ Fim do teste</h2>";
?>