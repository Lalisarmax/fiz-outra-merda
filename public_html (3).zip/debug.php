<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 Debug - Teste de Arquivos</h1>";

// Testar arquivos
$arquivos = [
    'conexao.php',
    'enviar_email.php',
    'verificar_email.php',
    'PHPMailer/src/Exception.php',
    'PHPMailer/src/PHPMailer.php',
    'PHPMailer/src/SMTP.php',
    'login.php',
    'cadastro.php'
];

echo "<h2>Verificando arquivos:</h2><ul>";
foreach ($arquivos as $arquivo) {
    $caminho = __DIR__ . '/' . $arquivo;
    if (file_exists($caminho)) {
        echo "<li style='color:green;'>✅ $arquivo existe</li>";
    } else {
        echo "<li style='color:red;'>❌ $arquivo NÃO existe</li>";
    }
}
echo "</ul>";

// Testar conexão
echo "<h2>Testando conexão:</h2>";
try {
    include 'conexao.php';
    echo "<p style='color:green;'>✅ conexao.php carregado</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
}

// Testar enviar_email.php
echo "<h2>Testando enviar_email.php:</h2>";
try {
    require 'enviar_email.php';
    echo "<p style='color:green;'>✅ enviar_email.php carregado</p>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
} catch (Error $e) {
    echo "<p style='color:red;'>❌ Erro fatal: " . $e->getMessage() . "</p>";
}

echo "<h2>✅ Teste concluído!</h2>";
?>