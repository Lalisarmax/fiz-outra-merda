<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "<h1>🔍 Debug 2 - Teste de Sessão e Cadastro</h1>";

// Testar session_start
echo "<h2>1. Iniciando sessão:</h2>";
session_start();
echo "<p style='color:green;'>✅ session_start() OK</p>";

// Mostrar conteúdo da sessão
echo "<h2>2. Conteúdo da SESSÃO:</h2>";
echo "<pre style='background:#f0f0f0; padding:12px; border-radius:8px;'>";
print_r($_SESSION);
echo "</pre>";

// Testar cadastro.php
echo "<h2>3. Testando inclusão do cadastro.php:</h2>";
echo "<p>Tentando incluir cadastro.php...</p>";

// Capturar erros
try {
    ob_start();
    include 'cadastro.php';
    $output = ob_get_clean();
    echo "<p style='color:green;'>✅ cadastro.php carregado (" . strlen($output) . " bytes)</p>";
    echo "<details>";
    echo "<summary>Ver primeiras 500 letras do HTML gerado</summary>";
    echo "<pre>" . htmlspecialchars(substr($output, 0, 500)) . "...</pre>";
    echo "</details>";
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
} catch (Error $e) {
    echo "<p style='color:red;'>❌ Erro Fatal: " . $e->getMessage() . " na linha " . $e->getLine() . "</p>";
}

echo "<h2>4. Testando verificar_email.php:</h2>";
echo "<p>Tentando incluir verificar_email.php...</p>";

// Simular sessão para verificar_email.php
$_SESSION['email_verificacao'] = 'teste@teste.com';
$_SESSION['nome_verificacao'] = 'Teste';

try {
    ob_start();
    include 'verificar_email.php';
    $output2 = ob_get_clean();
    echo "<p style='color:green;'>✅ verificar_email.php carregado (" . strlen($output2) . " bytes)</p>";
    if (strlen($output2) < 100) {
        echo "<p style='color:orange;'>⚠️ Saída muito curta! Provavelmente erro silencioso.</p>";
        echo "<pre>" . htmlspecialchars($output2) . "</pre>";
    }
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Erro: " . $e->getMessage() . "</p>";
} catch (Error $e) {
    echo "<p style='color:red;'>❌ Erro Fatal: " . $e->getMessage() . " na linha " . $e->getLine() . "</p>";
}

echo "<h2>✅ Teste concluído!</h2>";
?>