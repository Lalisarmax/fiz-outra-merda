<?php
session_start();
include 'conexao.php';

echo "<h1>✅ HomeCare - Teste</h1>";
echo "<p>Servidor funcionando!</p>";

if (isset($_SESSION['user_id'])) {
    echo "<p style='color:green;'>✅ Usuário logado: " . $_SESSION['user_nome'] . "</p>";
} else {
    echo "<p style='color:orange;'>⚠️ Nenhum usuário logado</p>";
}

echo "<p>Versão do PHP: " . phpversion() . "</p>";

// Testar conexão com banco
$result = $conn->query("SELECT COUNT(*) as total FROM usuarios");
if ($result) {
    $row = $result->fetch_assoc();
    echo "<p style='color:green;'>✅ Conexão com banco OK! Total de usuários: " . $row['total'] . "</p>";
}

// Mostrar todos os arquivos
echo "<h2>Arquivos no diretório:</h2>";
$files = scandir('.');
echo "<ul>";
foreach ($files as $file) {
    if ($file != '.' && $file != '..') {
        echo "<li>" . $file . "</li>";
    }
}
echo "</ul>";
?>